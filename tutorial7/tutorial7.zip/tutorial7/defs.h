#ifndef DEFS_H
#define DEFS_H

#define SLOCS  50
#define WHLOCS  100
#define SLOC_CAPACITY 20
#define WHLOC_CAPACITY 40

const std::string red("\033[0;31m");
const std::string def("\033[0m");

#endif
