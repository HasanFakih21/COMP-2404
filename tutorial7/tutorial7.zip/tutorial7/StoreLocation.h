#ifndef STORELOCATION_H
#define STORELOCATION_H

#include <iostream>
#include <string>

using namespace std;

static const char code = 'A';

class StoreLocation {
	public:
       
        
	
	private:
       
        
};
#endif